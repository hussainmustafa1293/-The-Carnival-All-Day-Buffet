/* ==========================================================================
   THE CARNIVAL — ALL DAY BUFFET
   Main JavaScript — Vanilla JS, GSAP, AOS, Swiper
   ========================================================================== */

document.addEventListener('DOMContentLoaded', function () {

  /* ---------------- LUXURY LOADER ---------------- */
  const loader = document.getElementById('loader');
  window.addEventListener('load', function () {
    setTimeout(() => { loader.classList.add('loaded'); }, 400);
  });
  // safety fallback in case 'load' fires slowly
  setTimeout(() => { loader.classList.add('loaded'); }, 3200);

  /* ---------------- AOS INIT ---------------- */
  if (window.AOS) {
    AOS.init({
      duration: 900,
      easing: 'ease-out-cubic',
      once: true,
      offset: 60
    });
  }

  /* ---------------- SCROLL PROGRESS BAR ---------------- */
  const progressBar = document.getElementById('scroll-progress');
  function updateProgress() {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const pct = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
    progressBar.style.width = pct + '%';
  }
  window.addEventListener('scroll', updateProgress);
  updateProgress();

  /* ---------------- CURSOR GLOW ---------------- */
  const glow = document.getElementById('cursor-glow');
  if (glow && window.matchMedia('(min-width: 993px)').matches) {
    window.addEventListener('mousemove', (e) => {
      glow.style.left = e.clientX + 'px';
      glow.style.top = e.clientY + 'px';
    });
  }

  /* ---------------- STICKY NAVBAR ---------------- */
  const nav = document.getElementById('mainNav');
  function handleNavScroll() {
    if (window.scrollY > 60) {
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
  }
  window.addEventListener('scroll', handleNavScroll);
  handleNavScroll();

  /* ---------------- MOBILE MENU ---------------- */
  const menuToggle = document.getElementById('menuToggle');
  const mobileMenu = document.getElementById('mobileMenu');
  const mobileMenuClose = document.getElementById('mobileMenuClose');
  const mobileLinks = document.querySelectorAll('.mobile-link');

  function openMobileMenu() {
    mobileMenu.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeMobileMenu() {
    mobileMenu.classList.remove('open');
    document.body.style.overflow = '';
  }
  if (menuToggle) menuToggle.addEventListener('click', openMobileMenu);
  if (mobileMenuClose) mobileMenuClose.addEventListener('click', closeMobileMenu);
  mobileLinks.forEach(link => link.addEventListener('click', closeMobileMenu));

  /* ---------------- ANIMATED COUNTERS ---------------- */
  const counters = document.querySelectorAll('.counter');
  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        counterObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.4 });
  counters.forEach(c => counterObserver.observe(c));

  function animateCounter(el) {
    const target = parseInt(el.getAttribute('data-count'), 10) || 0;
    const duration = 1800;
    const start = performance.now();
    function tick(now) {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const value = Math.floor(eased * target);
      el.textContent = value.toLocaleString();
      if (progress < 1) requestAnimationFrame(tick);
      else el.textContent = target.toLocaleString();
    }
    requestAnimationFrame(tick);
  }

  /* ---------------- 3D TILT ON CATEGORY CARDS ---------------- */
  const catCards = document.querySelectorAll('.cat-card-inner');
  catCards.forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const rotateX = ((y / rect.height) - 0.5) * -10;
      const rotateY = ((x / rect.width) - 0.5) * 14;
      card.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-6px) scale(1.02)`;
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
    });
  });

  /* ---------------- GSAP SCROLL ANIMATIONS ---------------- */
  if (window.gsap && window.ScrollTrigger) {
    gsap.registerPlugin(ScrollTrigger);

    gsap.utils.toArray('.section-title').forEach(title => {
      gsap.from(title, {
        y: 40,
        opacity: 0,
        duration: 1,
        ease: 'power3.out',
        scrollTrigger: { trigger: title, start: 'top 85%' }
      });
    });

    gsap.to('.gold-marquee', {
      backgroundPosition: '200px 0',
      ease: 'none',
      scrollTrigger: { trigger: '.gold-marquee', scrub: 1 }
    });
  }

  /* ---------------- SWIPER TESTIMONIALS ---------------- */
  if (window.Swiper) {
    new Swiper('.testimonial-swiper', {
      loop: true,
      autoplay: { delay: 4500, disableOnInteraction: false },
      pagination: { el: '.swiper-pagination', clickable: true },
      speed: 800
    });
  }

  /* ---------------- GALLERY LIGHTBOX ---------------- */
  const galleryItems = document.querySelectorAll('.gallery-item');
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightboxImg');
  const lightboxClose = document.getElementById('lightboxClose');

  galleryItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      lightboxImg.src = item.getAttribute('href');
      lightbox.classList.add('open');
    });
  });
  function closeLightbox() { lightbox.classList.remove('open'); lightboxImg.src = ''; }
  if (lightboxClose) lightboxClose.addEventListener('click', closeLightbox);
  lightbox && lightbox.addEventListener('click', (e) => { if (e.target === lightbox) closeLightbox(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeLightbox(); });

  /* ---------------- RESERVATION FORM VALIDATION ---------------- */
  const reservationForm = document.getElementById('reservationForm');
  const reservationPopup = document.getElementById('reservationPopup');
  const popupClose = document.getElementById('popupClose');

  if (reservationForm) {
    const inputs = reservationForm.querySelectorAll('input, textarea');
    inputs.forEach(input => {
      input.addEventListener('blur', () => input.classList.add('touched'));
    });

    reservationForm.addEventListener('submit', function (e) {
      e.preventDefault();
      let valid = true;
      reservationForm.querySelectorAll('input[required]').forEach(input => {
        input.classList.add('touched');
        if (!input.checkValidity()) valid = false;
      });
      if (valid) {
        reservationPopup.classList.add('open');
        reservationForm.reset();
        inputs.forEach(input => input.classList.remove('touched'));
      }
    });
  }
  if (popupClose) {
    popupClose.addEventListener('click', () => reservationPopup.classList.remove('open'));
  }

  /* ---------------- NEWSLETTER FORM ---------------- */
  const newsletterForm = document.getElementById('newsletterForm');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const input = newsletterForm.querySelector('input');
      if (input.checkValidity()) {
        input.value = '';
        input.placeholder = 'Subscribed — thank you!';
      }
    });
  }

  /* ---------------- BACK TO TOP ---------------- */
  const backToTop = document.getElementById('backToTop');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 500) backToTop.classList.add('show');
    else backToTop.classList.remove('show');
  });
  backToTop.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  /* ---------------- SMOOTH ANCHOR SCROLL ---------------- */
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (targetId.length > 1) {
        const target = document.querySelector(targetId);
        if (target) {
          e.preventDefault();
          const offset = 90;
          const top = target.getBoundingClientRect().top + window.scrollY - offset;
          window.scrollTo({ top, behavior: 'smooth' });
        }
      }
    });
  });

  /* ---------------- SET MIN DATE ON RESERVATION ---------------- */
  const dateInput = document.getElementById('rDate');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.setAttribute('min', today);
  }

});
